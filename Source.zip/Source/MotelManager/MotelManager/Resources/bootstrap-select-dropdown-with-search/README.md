# Hierarchy Select jQuery Plugin for Twitter Bootstrap 4

[![Build Status](https://travis-ci.com/NeoFusion/hierarchy-select.svg?branch=v2)](https://travis-ci.com/NeoFusion/hierarchy-select)

For Bootstrap 3 use [version 1.x](https://github.com/NeoFusion/hierarchy-select/tree/v1).
